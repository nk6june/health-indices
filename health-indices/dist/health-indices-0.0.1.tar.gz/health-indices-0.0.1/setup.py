# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['health_indices']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'health-indices',
    'version': '0.0.1',
    'description': 'a unified collection of health indices and indicators eg: bmi,bai,etc..',
    'long_description': "# Health-indices\nA unified collection of health indices and health indicators eg bmi,bai,corp index,etc\n\n#### Purpose of the Package\n+ The purpose of the package is to provide a collection of all health indices in one unified libary\n\n### Features\n+ Collection of Health indices\n    - BMI  \n    - BAI \n    - Corpulence index \n    - Piglet indices \n    - etc..\n+ Collection of Health indicators\n    - Mortality rate \n    - Birth rate\n    - Prevalence rate \n    - Fertility rate \n\n\n### Getting Started\nThe package can be found on pypi hence you can install it using pip\n\n#### Installation\n'''bash\npip install health_indices\n```\n\n### Usage\n#### Using the short forms or abbreviated forms of indices\n'''python\n>>> from health_indices import bmi,bai\n>>> bmi(54, 1.70)\n```\n#### Using the long form of indices\n'''python\n>>> from health_indices import bodymassindex\n>>> bodymassindex(54, 1.70)\n```\n\n### Examples\n```python\n>>> from health_indices import bmi\n>>> bmi(54,1.70)\nBody Mass Index is =>  18.0\nBMI Category => Underweight \nBody Mass Index is =>  18.0\n18.0\n>>> a = bmi(54,1.70)\nBody Mass Index is =>  18.0\nBMI Category => Underweight \nBody Mass Index is =>  18.0\n>>> a\n18.0\n>>>\n\n```\n### Contribution \nContributions are welcome Notice a bug let us know. Thanks\n\n### Author\n\n+ Main Maintainer: Naresh Kumar",
    'author': 'Naresh Kumar',
    'author_email': 'naresh.datascience@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/nk6june/health-indices',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
